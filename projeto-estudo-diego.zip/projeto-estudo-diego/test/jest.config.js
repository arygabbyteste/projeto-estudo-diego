module.exports = {
  rootDir: '../',
  verbose: false,
  bail: true,
  testEnvironment: 'node',
  testMatch: [
    '**/test/**/*.test.js',
  ],
}
