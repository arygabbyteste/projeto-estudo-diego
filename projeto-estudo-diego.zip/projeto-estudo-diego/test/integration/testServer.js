const request = require('supertest')
const app = require('../../src/server')

module.exports = request(app)
